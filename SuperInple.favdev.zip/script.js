// Create floating elements
        function createFloatingElements() {
            const container = document.getElementById('floatingElements');
            const elementsCount = 15;

            for (let i = 0; i < elementsCount; i++) {
                const element = document.createElement('div');
                element.classList.add('floating-element');

                const size = Math.random() * 60 + 20;
                element.style.width = `${size}px`;
                element.style.height = `${size}px`;
                element.style.left = `${Math.random() * 100}vw`;
                element.style.top = `${Math.random() * 100}vh`;
                element.style.background = `rgba(${Math.random() * 100}, ${
                  Math.random() * 100 + 155
               }, ${Math.random() * 100 + 200}, ${Math.random() * 0.3 + 0.1})`;
                element.style.animationDuration = `${Math.random() * 20 + 10}s`;
                element.style.animationDelay = `${Math.random() * 5}s`;

                container.appendChild(element);
            }
        }

        // Update date display
        function updateDateDisplay() {
            const now = new Date();
            const options = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
            };
            document.getElementById('dateDisplay').textContent =
                now.toLocaleDateString('en-US', options);
        }

        // Countdown timer - FIXED VERSION
        let countdownInterval;
        let targetTime;

        function initializeCountdown() {
            // Set target time to 5 seconds from now
            targetTime = new Date();
            targetTime.setSeconds(targetTime.getSeconds() + 5);

            // Start the countdown
            countdownInterval = setInterval(updateCountdown, 1000);
            updateCountdown(); // Run immediately to avoid 1-second delay
        }

        function updateCountdown() {
            const now = new Date();
            const diff = targetTime - now;

            if (diff <= 0) {
                // Countdown finished
                document.getElementById('days').textContent = '0';
                document.getElementById('hours').textContent = '00';
                document.getElementById('minutes').textContent = '00';
                document.getElementById('seconds').textContent = '00';

                // Show birthday card
                document.getElementById('birthdayCard').classList.add('visible');

                // Create balloons after 15 seconds
                createBalloons();

                // Stop the countdown
                clearInterval(countdownInterval);
                return;
            }

            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor(
                (diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60),
            );
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);

            document.getElementById('days').textContent = days;
            document.getElementById('hours').textContent = hours
                .toString()
                .padStart(2, '0');
            document.getElementById('minutes').textContent = minutes
                .toString()
                .padStart(2, '0');
            document.getElementById('seconds').textContent = seconds
                .toString()
                .padStart(2, '0');

            // Add animation to seconds when it changes
            if (seconds === 0) {
                document.getElementById('seconds').style.animation =
                    'countdownPop 0.5s';
                setTimeout(() => {
                    document.getElementById('seconds').style.animation = '';
                }, 500);
            }
        }

        // Create particles
        function createParticles(x, y, count, color) {
            const container = document.getElementById('particlesContainer');

            for (let i = 0; i < count; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');

                const size = Math.random() * 10 + 5;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${x}px`;
                particle.style.top = `${y}px`;
                particle.style.background =
                    color || `hsl(${Math.random() * 360}, 70%, 60%)`;

                const angle = Math.random() * Math.PI * 2;
                const velocity = Math.random() * 5 + 2;
                const vx = Math.cos(angle) * velocity;
                const vy = Math.sin(angle) * velocity;

                const animation = particle.animate(
                    [{
                        transform: `translate(0, 0)`,
                        opacity: 1,
                    }, {
                        transform: `translate(${vx * 100}px, ${vy * 100}px)`,
                        opacity: 0,
                    }, ], {
                        duration: Math.random() * 1000 + 500,
                        easing: 'cubic-bezier(0, .9, .57, 1)',
                    },
                );

                animation.onfinish = () => particle.remove();
                container.appendChild(particle);
            }
        }

        // Create confetti - IMPROVED VERSION
        function createConfetti() {
            const container = document.getElementById('particlesContainer');
            const confettiCount = 200;

            for (let i = 0; i < confettiCount; i++) {
                const confetti = document.createElement('div');
                confetti.classList.add('confetti-piece');

                const size = Math.random() * 10 + 5;
                const shapes = ['square', 'circle', 'triangle'];
                const shape = shapes[Math.floor(Math.random() * shapes.length)];

                confetti.style.width = `${size}px`;
                confetti.style.height = `${size * 2}px`;
                confetti.style.left = `${Math.random() * 100}vw`;
                confetti.style.background = `hsl(${
                  Math.random() * 360
               }, 70%, 60%)`;

                if (shape === 'circle') {
                    confetti.style.borderRadius = '50%';
                } else if (shape === 'triangle') {
                    confetti.style.clipPath =
                        'polygon(50% 0%, 0% 100%, 100% 100%)';
                }

                // Improved animation - now goes all the way to bottom
                const animation = confetti.animate(
                    [{
                        transform: `translate(0, 0) rotate(0deg)`,
                        opacity: 1,
                    }, {
                        transform: `translate(${
                           Math.random() * 200 - 100
                        }px, 100vh) rotate(${Math.random() * 720}deg)`,
                        opacity: 0,
                    }, ], {
                        duration: Math.random() * 3000 + 2000,
                        easing: 'cubic-bezier(0, .9, .57, 1)',
                    },
                );

                animation.onfinish = () => confetti.remove();
                container.appendChild(confetti);
            }
        }

        // Create balloons
        function createBalloons() {
            const container = document.getElementById('particlesContainer');
            const balloonCount = 10;
            const colors = [
                '#ff4081',
                '#4fc3f7',
                '#ffeb3b',
                '#4caf50',
                '#9c27b0',
                '#ff9800',
            ];

            for (let i = 0; i < balloonCount; i++) {
                const balloon = document.createElement('div');
                balloon.classList.add('balloon');

                balloon.style.left = `${Math.random() * 100}vw`;
                balloon.style.background =
                    colors[Math.floor(Math.random() * colors.length)];
                balloon.style.animationDuration = `${15 + Math.random() * 10}s`;
                balloon.style.animationDelay = `${Math.random() * 5}s`;

                // Add pop animation on click
                balloon.addEventListener('click', function() {
                    // Create particles at balloon position
                    const rect = balloon.getBoundingClientRect();
                    createParticles(
                        rect.left + rect.width / 2,
                        rect.top + rect.height / 2,
                        20,
                        balloon.style.background,
                    );

                    // Play pop sound
                    const popSound = new Audio(
                        'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAAAA==',
                    );
                    popSound.volume = 0.3;
                    popSound
                        .play()
                        .catch((e) => console.log('Audio play failed:', e));

                    // Remove balloon with animation
                    balloon.style.animation = 'balloonPop 0.5s forwards';
                    setTimeout(() => {
                        if (balloon.parentNode) {
                            balloon.remove();
                        }
                    }, 500);
                });

                container.appendChild(balloon);
            }
        }

        // Blow out candle
        function blowOutCandle() {
            const flame = document.getElementById('candleFlame');
            if (!flame) return;

            flame.style.animation = 'none';
            flame.style.opacity = '0';

            // Create smoke particles
            const rect = flame.getBoundingClientRect();
            createParticles(
                rect.left + rect.width / 2,
                rect.top,
                10,
                'rgba(200, 200, 200, 0.7)',
            );

            // Change message
            const messageElement = document.querySelector(
                '.birthday-message p',
            );
            if (messageElement) {
                messageElement.innerHTML =
                    "Your wish has been sent to the repository! <i class='fas fa-code-branch'></i>";
            }
        }

        // Initialize - CORRECTED VERSION
        document.addEventListener('DOMContentLoaded', () => {
            createFloatingElements();
            updateDateDisplay();

            // Initialize and start countdown
            initializeCountdown();

            // Event listeners
            document
                .getElementById('confettiBtn')
                .addEventListener('click', createConfetti);
            document
                .getElementById('candleFlame')
                .addEventListener('click', blowOutCandle);
            document
                .getElementById('balloonBtn')
                .addEventListener('click', createBalloons);

            document
                .getElementById('messageBtn')
                .addEventListener('click', () => {
                    const messages = [
                        'May your code always be bug-free!',
                        'Wishing you infinite stack overflow points!',
                        "Here's to another year of clean commits!",
                        'May your APIs always return 200!',
                        'Happy birthday to a debugging master!',
                        'May your deployments always be successful!',
                        "Here's to fewer bugs and more features!",
                        'Wishing you fast compile times and smooth debugging!',
                    ];
                    const randomMessage =
                        messages[Math.floor(Math.random() * messages.length)];
                    const messageElement = document.querySelector(
                        '.birthday-message p',
                    );
                    if (messageElement) {
                        messageElement.textContent = randomMessage;
                    }

                    // Add particles
                    createParticles(
                        window.innerWidth / 2,
                        window.innerHeight / 2,
                        20,
                        '#00b4db',
                    );
                });

            const music = document.getElementById('birthdayMusic');
            let musicPlaying = false;

            document
                .getElementById('musicBtn')
                .addEventListener('click', () => {
                    if (musicPlaying) {
                        music.pause();
                        document.getElementById('musicBtn').innerHTML =
                            '<i class="fas fa-music"></i> Play Music';
                    } else {
                        music
                            .play()
                            .catch((e) => console.log('Audio play failed:', e));
                        document.getElementById('musicBtn').innerHTML =
                            '<i class="fas fa-pause"></i> Pause Music';
                    }
                    musicPlaying = !musicPlaying;
                });

            // Add click effect
            document.addEventListener('click', (e) => {
                createParticles(e.clientX, e.clientY, 5, '#00b4db');
            });
        });